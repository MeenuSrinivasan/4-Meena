#include "thingProperties.h"
#include <SPI.h>
#include <MFRC522.h>
#include <Arduino.h>

#define SS_PIN D4   // SDA (SS) pin connected to D4 (GPIO2)
#define RST_PIN D1  // RST pin connected to D1 (GPIO5)
#define BUZZER 15   // Buzzer connected to D3 (GPIO15)
#define MQ135_PIN A0 // Digital pin connected to MQ135 sensor

MFRC522 mfrc522(SS_PIN, RST_PIN);
int sensorValue = 0;  // Global sensor value
unsigned long startTime;  // Variable to track time

void setup() {
  Serial.begin(9600);
  delay(1500);  // Ensure the serial monitor is ready
  
  initProperties();  // Initialize cloud properties
  ArduinoCloud.begin(ArduinoIoTPreferredConnection);
  
  setDebugMessageLevel(2);
  ArduinoCloud.printDebugInfo();
  
  SPI.begin();
  mfrc522.PCD_Init();  // Initialize RFID reader
  
  pinMode(BUZZER, OUTPUT);
  digitalWrite(BUZZER, LOW);

  alcohol = 0;  // ✅ Set alcohol to 0 initially
  startTime = millis();  // Store the current time

  Serial.println("Scan your RFID card...");
}

void loop() {
  ArduinoCloud.update();  // Update cloud variables

  // Check if 50 seconds have passed
  if (millis() - startTime >= 50000) {  
    alcohol = 30;  // ✅ Raise alcohol value to 30 after 50 sec
  }

  if (!mfrc522.PICC_IsNewCardPresent() || !mfrc522.PICC_ReadCardSerial()) {
    return;
  }

  Serial.print("Card UID: ");
  String tagID = "";
  
  for (byte i = 0; i < mfrc522.uid.size; i++) {
    tagID += String(mfrc522.uid.uidByte[i], HEX);
  }

  Serial.println(tagID);

  if (tagID == "73ed98e4") {  // Replace with actual UID
    Serial.println("Access Granted!\nDriver safety detected\nALCOHOL STATUS GOOD\nAIR QUALITY STATUS GOOD");
    
    digitalWrite(BUZZER, HIGH);
    delay(2000);
    digitalWrite(BUZZER, LOW);
    
    rfid = 0;  // Update RFID status
  } else {
    Serial.println("Access Denied!");
    mfrc522.PICC_HaltA();
  }

  // Air Quality Logic
  sensorValue = analogRead(MQ135_PIN);
  airQuality = sensorValue;

  float voltage = sensorValue * (3.3 / 1024.0);
  Serial.print("Sensor Value: ");
  Serial.print(sensorValue);
  Serial.print(" | Voltage: ");
  Serial.print(voltage);
  Serial.println("V");

  Serial.print("Alcohol Level: ");
  Serial.println(alcohol);  // ✅ Display alcohol level

  delay(1000);
}

void buzz(int times, int duration) {
  for (int i = 0; i < times; i++) {
    digitalWrite(BUZZER, HIGH);
    delay(duration);
    digitalWrite(BUZZER, LOW);
    delay(100);
  }
}

// Functions to handle changes in cloud variables
void onAlcoholChange() {
  Serial.println("Alcohol value changed");
}

void onAirQualityChange() {
  Serial.println("Air Quality value changed");
}

void onRfidChange() {
  Serial.println("RFID value changed");
}

void onDustqualityChange() {
  Serial.println("Dust Quality value changed");
}
